Markers created in GIMP (https://www.gimp.org/) using the Alchemy font by Kenneth Hirst.

Created for use in MapTool (https://www.rptools.net) but may be used wherever and however you like.

Phergus on the MapTool Discord server and RPTools.net forums.

2019-12-24